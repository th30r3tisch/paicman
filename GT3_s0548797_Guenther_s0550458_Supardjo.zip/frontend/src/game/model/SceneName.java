package game.model;

public enum SceneName {
    LOGIN, WORLD;
}