package game.model.units;

public class Attacker extends Unit {

    private int damage;

    public Integer getDamage() {
        return damage;
    }

    public void setDamage(Integer damage) {
        this.damage = damage;
    }
}
